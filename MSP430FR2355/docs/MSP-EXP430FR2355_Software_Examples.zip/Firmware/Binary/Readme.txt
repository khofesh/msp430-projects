Using TI Uniflash to download pre-built TI-TXT images
1. Visit https://dev.ti.com/uniflash/
2. Choose your Board/Device
3. Click Start
4. Browse and upload the TI-TXT images you wish to download from this folder
5. Click "Load Image" to download the image to your LaunchPad using your browser

If you wish to use TI UniFlash in standalone/offline
7. Go to "Standalone Command Line" after uploading the image file
8. Ensure the right image is selected
9. "Generate Package" for your OS
